<?php
require('dbconn.php');

$id = $_GET['id'];
$roll = $_SESSION['RollNo'];

// Check if the record already exists
$checkSql = "SELECT * FROM LMS.record WHERE RollNo='$roll' AND BookId='$id'";
$result = $conn->query($checkSql);

if ($result->num_rows > 0) {
    echo "<script type='text/javascript'>alert('Request Already Sent.')</script>";
    header("Refresh:0.01; url=book.php", true, 303);
} else {
    // Insert the record if it doesn't exist
    $sql = "INSERT INTO LMS.record (RollNo, BookId, Time) VALUES ('$roll', '$id', CURTIME())";

    if ($conn->query($sql) === TRUE) {
        echo "<script type='text/javascript'>alert('Request Sent to Admin.')</script>";
        header("Refresh:0.01; url=book.php", true, 303);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
